from game.casting.actor import Actor

# TODO: Implement the Artifact class here. Don't forget to inherit from Actor!